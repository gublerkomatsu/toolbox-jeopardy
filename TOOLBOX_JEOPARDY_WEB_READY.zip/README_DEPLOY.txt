TOOLBOX JEOPARDY - WEB DEPLOYMENT

This folder is ready to upload to a web host.

FASTEST OPTION: Netlify Drop
1. Go to https://app.netlify.com/drop
2. Drag this entire folder onto the page.
3. Netlify will create a public link you can share.

GITHUB PAGES OPTION
1. Create a new GitHub repository.
2. Upload index.html to the repository.
3. Go to Settings > Pages.
4. Under Source, select Deploy from branch.
5. Choose main branch and root folder.
6. GitHub will generate a public website link.

ANY BASIC WEBSITE HOST
Upload index.html to the root of your site.
The game is self-contained and does not need any other files.
